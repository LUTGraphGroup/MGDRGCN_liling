# import numpy as np
# import matplotlib.pyplot as plt
# import csv
# import matplotlib
# import matplotlib.pyplot as plt
# import matplotlib.ticker as ticker
# import numpy as np
# print(plt.style.available)
# # 加载三个实验的FPR和TPR数据
# fpr_exp1 = np.load(r'F:\daixie\111\exp\bi-random walks\Dataset2\fpr.npy')  # 实验1的FPR数据
# tpr_exp1 = np.load(r'F:\daixie\111\exp\bi-random walks\Dataset2\tpr.npy')  # 实验1的TPR数据
#
# fpr_exp2 = np.load(r'F:\daixie\111\exp\DiMiMe-main\DiMiMe-main\code\Dataset2\fpr.npy')  # 实验2的FPR数据
# tpr_exp2 = np.load(r'F:\daixie\111\exp\DiMiMe-main\DiMiMe-main\code\Dataset2\tpr.npy')  # 实验2的TPR数据
#
# # fpr_exp3 = np.load(r'F:\daixie\111\exp\GCNAT_Pytorch\Dataset2\fpr.npy')  # 实验3的FPR数据
# # tpr_exp3 = np.load(r'F:\daixie\111\exp\GCNAT_Pytorch\Dataset2\tpr.npy')  # 实验3的TPR数据
# auc3 = np.load(r'F:\疾病预测\shiyan\b\roc\roc1.npy')
#
# fpr_exp5 = np.load(r'F:\daixie\111\exp\RCNMF\Dataset2\fpr.npy')  # 实验3的FPR数据
# tpr_exp5 = np.load(r'F:\daixie\111\exp\RCNMF\Dataset2\tpr.npy')  # 实验3的TPR数据
# data1 = []
# with open(r'F:\daixie\111\exp\GMNN2CD-2022\Dataset2\fpr_arr_mean_att.csv', 'r') as csvfile:
#     csvreader = csv.reader(csvfile)
#     for row in csvreader:
#         data1.append(row)
# data2 = []
# with open(r'F:\daixie\111\exp\GMNN2CD-2022\Dataset2\tpr_arr_mean_att.csv', 'r') as csvfile:
#     csvreader = csv.reader(csvfile)
#     for row in csvreader:
#         data2.append(row)
#
# fpr_exp4 = data1
# tpr_exp4 = data2
# fpr_exp4 = np.array(fpr_exp4).astype(float)
# tpr_exp4 = np.array(tpr_exp4).astype(float)
#
# # 计算三个实验的AUC
# auc1 = np.load(r'F:\daixie\New folder\roc\roc.npy')
# auc_exp1 = np.trapz(tpr_exp1, fpr_exp1)
# auc_exp2 = np.trapz(tpr_exp2, fpr_exp2)
# # auc_exp3 = np.trapz(tpr_exp3, fpr_exp3)
# auc_exp4 = np.trapz(tpr_exp4, fpr_exp4)
# auc_exp4_value = np.mean(auc_exp4)
# auc_exp5 = np.trapz(tpr_exp5, fpr_exp5)
#
# plt.plot(np.linspace(0, 1, 101), auc1, color='red',label=f'RDAMAN: 0.9630')
# plt.plot(fpr_exp1, tpr_exp1,color='blue',label=f'Experiment 1 (AUC = {auc_exp1:.4f})')
# plt.plot(fpr_exp2, tpr_exp2,color='green', lw=2, label=f'Experiment 2 (AUC = {auc_exp2:.4f})')
# # plt.plot(fpr_exp3, tpr_exp3, lw=2, label=f'Experiment 3 (AUC = {auc_exp3:.4f})')
# plt.plot(np.linspace(0, 1, 101), auc3, color='purple',label=f'RDAMAN: 0.8747')
# plt.plot(fpr_exp4[1], tpr_exp4[1],color='cyan', lw=2, label=f'Experiment 4 (AUC = {auc_exp4_value:.4f})')
# plt.plot(fpr_exp5, tpr_exp5, color='orange',lw=2, label=f'Experiment 5 (AUC = {auc_exp5:.4f})')
#
# plt.plot([0, 1], [0, 1], 'k--')
# ax = plt.gca()
#
# ax.spines['left'].set_position(('data', -0.05))
# ax.spines['bottom'].set_position(('data', -0.05))
# ax.spines['right'].set_position(('data', -0.5))
# ax.spines['top'].set_position(('data', -0.5))
#
# ax.annotate('0', xy=(0.1, 0), xytext=(3, -15), textcoords='offset points', ha='center', va='center')
# ax.annotate('0', xy=(0, 0.1), xytext=(-15, 3), textcoords='offset points', ha='center', va='center')
#
# plt.legend()
# plt.xlim([0, 1])
# plt.ylim([0, 1])
# plt.xlabel('False Positive Rate')
# plt.ylabel('True Positive Rate')
# plt.title('Receiver Operating Characteristic (ROC) Curve')
# plt.legend(loc="lower right")
# plt.grid(False)
#
# # # plt.subplots_adjust(left=0.1, right=0.95, top=0.95, bottom=0.1)  # 调整外边距
# # # plt.tight_layout()
# # ax = plt.gca()
# # ax.xaxis.labelpad = 100
# # ax.yaxis.labelpad = 100
# plt.savefig('roc_curve.png')
# plt.show()
# plt.savefig('ROCcurve_comp.jpg')
import numpy as np
import matplotlib.pyplot as plt
import csv
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
print(plt.style.available)
# 加载三个实验的FPR和TPR数据
fpr_exp1 = np.load(r'F:\daixie\111\exp\bi-random walks\Dataset2\fpr.npy')  # 实验1的FPR数据
tpr_exp1 = np.load(r'F:\daixie\111\exp\bi-random walks\Dataset2\tpr.npy')  # 实验1的TPR数据

fpr_exp2 = np.load(r'F:\daixie\111\exp\DiMiMe-main\DiMiMe-main\code\Dataset2\fpr.npy')  # 实验2的FPR数据
tpr_exp2 = np.load(r'F:\daixie\111\exp\DiMiMe-main\DiMiMe-main\code\Dataset2\tpr.npy')  # 实验2的TPR数据

# fpr_exp3 = np.load(r'F:\daixie\111\exp\GCNAT_Pytorch\Dataset2\fpr.npy')  # 实验3的FPR数据
# tpr_exp3 = np.load(r'F:\daixie\111\exp\GCNAT_Pytorch\Dataset2\tpr.npy')  # 实验3的TPR数据
auc3 = np.load(r'F:\疾病预测\shiyan\b\roc\roc1.npy')

fpr_exp5 = np.load(r'F:\daixie\111\exp\RCNMF\Dataset2\fpr.npy')  # 实验3的FPR数据
tpr_exp5 = np.load(r'F:\daixie\111\exp\RCNMF\Dataset2\tpr.npy')  # 实验3的TPR数据
data1 = []
with open(r'F:\daixie\111\exp\GMNN2CD-2022\Dataset2\fpr_arr_mean_att.csv', 'r') as csvfile:
    csvreader = csv.reader(csvfile)
    for row in csvreader:
        data1.append(row)
data2 = []
with open(r'F:\daixie\111\exp\GMNN2CD-2022\Dataset2\tpr_arr_mean_att.csv', 'r') as csvfile:
    csvreader = csv.reader(csvfile)
    for row in csvreader:
        data2.append(row)

fpr_exp4 = data1
tpr_exp4 = data2
fpr_exp4 = np.array(fpr_exp4).astype(float)
tpr_exp4 = np.array(tpr_exp4).astype(float)

# 计算三个实验的AUC
auc1 = np.load(r'F:\daixie\New folder\roc\roc.npy')
auc_exp1 = np.trapz(tpr_exp1, fpr_exp1)
auc_exp2 = np.trapz(tpr_exp2, fpr_exp2)
# auc_exp3 = np.trapz(tpr_exp3, fpr_exp3)
auc_exp4 = np.trapz(tpr_exp4, fpr_exp4)
auc_exp4_value = np.mean(auc_exp4)
auc_exp5 = np.trapz(tpr_exp5, fpr_exp5)

plt.plot(np.linspace(0, 1, 101), auc1, color='red',label=f'MGDHGS: 0.9734')
plt.plot(fpr_exp1, tpr_exp1,color='blue',label=f'MDBIRW  {auc_exp1:.4f}')
plt.plot(fpr_exp2, tpr_exp2,color='green', lw=2, label=f'DiMiMe {auc_exp2:.4f}')
# plt.plot(fpr_exp3, tpr_exp3, lw=2, label=f'Experiment 3 (AUC = {auc_exp3:.4f})')
plt.plot(np.linspace(0, 1, 101), auc3, color='purple',label=f'GCNAT: 0.7383')
plt.plot(fpr_exp4[1], tpr_exp4[1],color='cyan', lw=2, label=f'DWRF {auc_exp4_value:.4f}')
plt.plot(fpr_exp5, tpr_exp5, color='orange',lw=2, label=f'RCNMF {auc_exp5:.4f}')

plt.plot([0, 1], [0, 1], 'k--')
ax = plt.gca()
plt.legend()
plt.xlim([-0.05, 1.05])
plt.ylim([-0.05, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')

plt.legend(loc="lower right")
plt.grid(False)
plt.savefig('roc_curve.png')
plt.show()
