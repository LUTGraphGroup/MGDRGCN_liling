# #二分类focal loss
# import torch
# import torch.nn as nn
#
# class BinaryFocalLoss(nn.Module):
#     def __init__(self, alpha=0.5, gamma=2):
#         super(BinaryFocalLoss, self).__init__()
#         self.alpha = alpha
#         self.gamma = gamma
#         self.sigmoid = nn.Sigmoid()
#
#     def forward(self, preds, labels, eps=1e-7):
#         preds = self.sigmoid(preds)
#         pos_loss = -1 * self.alpha * torch.pow((1 - preds), self.gamma) * torch.log(preds + eps) * labels
#         neg_loss = -1 * (1 - self.alpha) * torch.pow(preds, self.gamma) * torch.log(1 - preds + eps) * (1 - labels)
#         return torch.mean(pos_loss + neg_loss) * 4


import torch
import torch.nn as nn
import torch.nn.functional as F


class FocalLoss(nn.Module):
    def __init__(self, gamma=2, alpha=0.5):
        super(FocalLoss, self).__init__()
        self.gamma = gamma
        self.alpha = alpha

    def forward(self, inputs, targets):
        BCE_loss = F.binary_cross_entropy_with_logits(inputs, targets, reduction='none')
        pt = torch.exp(-BCE_loss)
        focal_loss = self.alpha * (1 - pt) ** self.gamma * BCE_loss
        return focal_loss.mean() * 5


focal_loss = FocalLoss()
