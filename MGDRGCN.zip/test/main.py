from dataset import train_list,val_list
from model import Model
from loss import focal_loss
import numpy as np
import matplotlib.pyplot as plt
import torch
import torch.nn.functional as F
from torch_geometric.loader import LinkNeighborLoader
from sklearn.metrics import roc_auc_score,classification_report,precision_recall_curve,average_precision_score
from sklearn.metrics import accuracy_score,recall_score,precision_score,f1_score
from sklearn.metrics import roc_curve, precision_recall_curve, roc_auc_score, average_precision_score,classification_report
import torch.nn as nn
#可重复性，固定seed
from torch_geometric import seed_everything

seed_everything(204)
torch.manual_seed(204)
np.random.seed(204)

# 检查是否能使用gpu，如果能使用device=cuda
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

print("Using device:", device)
plt.rcParams['figure.dpi'] = 300
# 验证
def eval_loop(val_loader, fold=0, device='cpu'):
    model = Model(hidden_channels=128).to(device)
    model.load_state_dict(torch.load(f'./model/best_model_{fold}.pth'))
    model.eval()
    preds = []
    ground_truths = []
    for sampled_data in val_loader:
        with torch.no_grad():
            sampled_data.to(device)
            preds.append(model(sampled_data))
            ground_truths.append(sampled_data["diease", "association1", "met"].edge_label)
    pred = torch.cat(preds, dim=0)
    pred = F.sigmoid(pred).cpu().numpy()
    ground_truth = torch.cat(ground_truths, dim=0).cpu().numpy()
    pred_return = pred.copy()
    ground_truth_return = ground_truth.copy()
    auc = roc_auc_score(ground_truth, pred)
    fpr, tpr, thresholds = roc_curve(ground_truth, pred)
    #plt.plot(fpr, tpr, label=f'fold {fold}')
    #plt.legend()
    #plt.xlabel('False positive rate')
    #plt.ylabel('True positive rate')
    #plt.savefig(f'./roc/ROC curve fold {fold}')
    pred = (pred >= 0.5).astype(np.int64)
    print(f"Validation AUC of fold {fold}: {auc:.4f}")
    print(classification_report(ground_truth, pred,zero_division=0.0))
    return pred_return,ground_truth_return,auc

def train_eval_loop(train_loader, val_loader, epochs=50, fold=0, device='cpu',weight_decay=1e-4):
    # 模型参数
    model = Model(hidden_channels=128).to(device)
    # optimizer = torch.optim.SGD(model.parameters(), lr=1e-2, weight_decay=weight_decay)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
    loss_list = []
    best_auc = 0.0
    best_epoch = 0
    best_val_loss = np.inf
    # 训练验证循环
    for epoch in range(1, epochs + 1):
        # 训练
        model.train()
        total_loss = total_examples = 0
        preds = []
        ground_truths = []
        for sampled_data in train_loader:
            optimizer.zero_grad()
            sampled_data.to(device)
            pred = model(sampled_data)
            ground_truth = sampled_data["diease", "association1", "met"].edge_label
            preds.append(pred)
            ground_truths.append(ground_truth)
            # loss = F.binary_cross_entropy_with_logits(pred, ground_truth)
            loss = focal_loss(pred, ground_truth)
            loss.backward()
            optimizer.step()
            total_loss += float(loss) * pred.numel()
            total_examples += pred.numel()
            
            torch.save(model.state_dict(), f'./model/last_model.pth')
            
        loss = total_loss / total_examples
        print(f"Epoch: {epoch:03d}, Train Loss: {loss:.4f} | ")
        loss_list.append(loss)
        pred = torch.cat(preds, dim=0)
        ground_truth = torch.cat(ground_truths, dim=0).detach().cpu().numpy()
        pred = F.sigmoid(pred).detach().cpu().numpy()

        auc = roc_auc_score(ground_truth, pred)
        pred = (pred >= 0.5).astype(np.int64)
        acc = accuracy_score(ground_truth,pred)
        recall = recall_score(ground_truth,pred,zero_division=0.0)
        pre = precision_score(ground_truth, pred,zero_division=0.0)
        f1 = f1_score(ground_truth, pred,zero_division=0.0)
        print(f"Epoch: {epoch:03d} | Train loss: {loss:.4f}| Train acc: {acc:.4f}| Train AUC: {auc:.4f}| Train Precesion: {pre:.4f}| Train recall: {recall:.4f}| Train f1: {f1:.4f}")
        #scheduler.step()

        # 验证
        model.eval()
        preds = []
        ground_truths = []
        for sampled_data in val_loader:
            with torch.no_grad():
                sampled_data.to(device)
                preds.append(model(sampled_data))
                ground_truths.append(sampled_data["diease", "association1", "met"].edge_label)
        pred = torch.cat(preds, dim=0)
        ground_truth = torch.cat(ground_truths, dim=0)
        loss = F.binary_cross_entropy_with_logits(pred, ground_truth)
        pred = F.sigmoid(pred).cpu().numpy()
        ground_truth = ground_truth.cpu().numpy()
        auc = roc_auc_score(ground_truth, pred)
        pred = (pred >= 0.5).astype(np.int64)
        acc = accuracy_score(ground_truth,pred)
        recall = recall_score(ground_truth,pred,zero_division=0.0)
        pre = precision_score(ground_truth, pred,zero_division=0.0)
        f1 = f1_score(ground_truth, pred,zero_division=0.0)
        print(f"Epoch: {epoch:03d} | Val loss: {loss:.4f}| Val acc: {acc:.4f}| Val AUC: {auc:.4f}| Val Precesion: {pre:.4f}| Val recall: {recall:.4f}| Val f1: {f1:.4f}")
        if best_auc < auc:
            best_auc = auc
            best_epoch = epoch
            torch.save(model.state_dict(), f'./model/best_model_{fold}.pth')
        print(f"best epoch :{best_epoch:03d} | Best auc :{best_auc:.4f} ")

    plt.plot(loss_list, label=f'Fold {fold}')
    plt.legend()
    plt.xlabel('Epoches')
    plt.ylabel('Loss')
    plt.savefig(f"./loss/loss_fold_{fold}.jpg")

# 训练
for i in range(5):
    edge_label_index = train_list[i]["diease", "association1", "met"].edge_label_index
    edge_label = train_list[i]["diease", "association1", "met"].edge_label
    train_loader = LinkNeighborLoader(
        data=train_list[i],
        num_neighbors=[20, 10],
        neg_sampling_ratio=1.0,
        edge_label_index=(("diease", "association1", "met"), edge_label_index),
        edge_label=edge_label,
        batch_size=32,
        shuffle=True,
    )

    edge_label_index_val = val_list[i]["diease", "association1", "met"].edge_label_index
    edge_label_val = val_list[i]["diease", "association1", "met"].edge_label
    val_loader = LinkNeighborLoader(
        data=val_list[i],
        num_neighbors=[20, 10],
        edge_label_index=(["diease", "association1", "met"], edge_label_index_val),
        edge_label=edge_label_val,
        batch_size=128,
        shuffle=False,
    )
    train_eval_loop(train_loader, val_loader, epochs=30, fold=i, device=device)


plt.close()
# 预测
pred_lists =[]
gt_lists = []
auc_sum = 0.0
for i in range(5):
    edge_label_index = val_list[i]["diease", "association1", "met"].edge_label_index
    edge_label = val_list[i]["diease", "association1", "met"].edge_label
    val_loader = LinkNeighborLoader(
        data=val_list[i],
        num_neighbors=[20, 10],
        edge_label_index=(["diease", "association1", "met"], edge_label_index),
        edge_label=edge_label,
        batch_size=128,
        shuffle=False,
    )

    #auc_list.append(eval_loop(val_loader, fold=i, device=device))
    p,g,a = eval_loop(val_loader, fold=i, device=device)
    auc_sum += a
    pred_lists.append(p)
    gt_lists.append(g)

plt.close()
auc_sum = 0
fpr_list = []
tpr_list = []
recall_sum = 0.0
for fold, (ground_truth, pred) in enumerate(zip(gt_lists, pred_lists)):
    auc = roc_auc_score(ground_truth, pred)
    auc_sum += auc
    fpr, tpr, thresholds = roc_curve(ground_truth, pred)
    fpr_list.append(fpr)
    tpr_list.append(tpr)
    plt.plot(fpr, tpr, label=f'fold {fold} AUC: {auc:.4f}')

def interpolate(x_list, y_list):
    y_l = []
    for i, (x, y) in enumerate(zip(x_list, y_list)):
        y_l.append(np.interp(np.linspace(0, 1, 101), x, y))
    return np.average(np.array(y_l), axis=0)

average_roc_curve = interpolate(fpr_list, tpr_list)
plt.plot(np.linspace(0, 1, 101), average_roc_curve, 'r--', label=f'Average AUC: {auc_sum/5:.4f}')
np.save('./roc/roc.npy', average_roc_curve)
plt.plot([0, 1], [0, 1], 'k--')
plt.legend()
plt.xlabel('False positive rate')
plt.ylabel('True positive rate')

# 添加局部放大的代码
ax = plt.gca()
axins = ax.inset_axes([0.6, 0.6, 0.35, 0.35])  # 定义局部放大的区域，参数为[left, bottom, width, height]


# 在局部放大区域绘制ROC曲线
for fold, (fpr, tpr) in enumerate(zip(fpr_list, tpr_list)):
    axins.plot(fpr, tpr)
axins.plot(np.linspace(0, 1, 101), average_roc_curve, 'r--', label=f'Average AUC: {auc_sum/5:.4f}')  # 添加平均曲线
axins.plot([0, 1], [0, 1], 'k--')  # 绘制参考线
axins.set_xlim(0.05, 0.15)  # 设置局部放大区域的x轴范围
axins.set_ylim(0.8, 0.95)  # 设置局部放大区域的y轴范围
axins.legend()

# 禁用局部放大图的图注
axins.legend_.set_visible(False)
# 将局部放大区域添加到主图中
ax.indicate_inset_zoom(axins)

plt.savefig(f'./roc/ROCcurve.jpg')
plt.close()


acc_list = []
pre_list = []
roc_auc_list = []
f1_list = []

auprc_sum = 0
precision_list = []
recall_list = []
for fold,(ground_truth, pred) in enumerate(zip(gt_lists,pred_lists)):
    auprc = average_precision_score(ground_truth, pred)
    auprc_sum += auprc
    precision, recall, thresholds = precision_recall_curve(ground_truth, pred)
    precision = np.insert(precision, 0, 0.0)
    recall = np.insert(recall, 0, 1.0)
    precision_list.append(precision)
    recall_list.append(recall)

    recall_fold = recall_score(ground_truth, (pred >= 0.5).astype(np.int64))
    recall_sum += recall_fold

    # 计算其他指标
    acc = accuracy_score(ground_truth, (pred >= 0.5).astype(np.int64))
    pre = precision_score(ground_truth, (pred >= 0.5).astype(np.int64), zero_division=0.0)
    roc_auc = roc_auc_score(ground_truth, pred)
    f1 = f1_score(ground_truth, (pred >= 0.5).astype(np.int64), zero_division=0.0)

    # 将指标添加到列表中
    acc_list.append(acc)
    pre_list.append(pre)
    roc_auc_list.append(roc_auc)
    f1_list.append(f1)

    # 绘制AUPRC曲线
    plt.plot(precision, recall, label=f'fold {fold} AUPRC: {auprc:.4f}')
avg_acc = sum(acc_list) / len(acc_list)
avg_pre = sum(pre_list) / len(pre_list)
avg_roc_auc = sum(roc_auc_list) / len(roc_auc_list)
avg_f1 = sum(f1_list) / len(f1_list)
avg_recall = recall_sum / len(gt_lists)
plt.plot(np.linspace(0,1,101),interpolate(precision_list,recall_list),'r--',label=f'Average AUPRC: {auprc_sum/5:.4f}')
np.save('./roc/roc.npy',interpolate(fpr_list,tpr_list))
plt.plot([0,1],[1,0],'k--')
plt.legend(loc='lower left')
plt.xlabel('Precision')
plt.ylabel('Recall')

# 添加局部放大的代码
ax = plt.gca()
axins = ax.inset_axes([0.1, 0.6, 0.35, 0.35])  # 定义局部放大的区域，参数为[left, bottom, width, height]

# 在局部放大区域绘制AUPRC曲线
for fold, (precision, recall) in enumerate(zip(precision_list, recall_list)):
    axins.plot(precision, recall, label=f'fold {fold} AUPRC: {auprc:.4f}')

# 计算并绘制平均AUPRC曲线
avg_auprc = auprc_sum / len(gt_lists)
avg_precision_curve = interpolate(precision_list, recall_list)
axins.plot(np.linspace(0, 1, 101), avg_precision_curve, 'r--', label=f'Average AUPRC: {avg_auprc:.4f}')

# 设置局部放大区域的x轴和y轴范围
axins.set_xlim(0.9, 1.0)  # 设置x轴范围
axins.set_ylim(0.7, 0.9)  # 设置y轴范围

# 将局部放大区域添加到主图中
ax.indicate_inset_zoom(axins)

# 保存图像
plt.savefig(f'./roc/PRC.jpg')
print(f"Average acc：{avg_acc:.4f}")
print(f"Average pre：{avg_pre:.4f}")
# print(f"Average ROC：{avg_roc_auc:.4f}")
print(f"Average F1：{avg_f1:.4f}")
print(f"Average Recall: {avg_recall:.4f}")
print('Average AUC of 5 folds is:', auc_sum/5)