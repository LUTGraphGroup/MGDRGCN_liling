from sklearn.decomposition import PCA
import pandas as pd
import os.path as osp
import pickle


class PCATrans:
    def __init__(self, is_train=True):
        self.save_fold = './PCA_weight'
        self.feat_save_root = './data'
        self.file_name_list = ['dieaseSmi2.csv',
                               'geneSim2.csv', 'metSim2.csv']
        self.pca_map = {}
        self.train_pca()


    def train_pca(self, reduction=2):
        # if not osp.isdir(self.save_fold):
        #     os.makedirs(self.save_fold)
        for file_name in self.file_name_list:
            dat = pd.read_csv(osp.join(self.feat_save_root, file_name), header=None).values
            pca = PCA(n_components=int(dat.shape[1] / reduction))
            pca.fit(dat)
            self.pca_map[osp.splitext(file_name)[0]] = pca
            # pca_save_path = osp.join(self.save_fold, file_name.replace('csv', 'pca'))
            # with open(pca_save_path, 'wb') as f:
            #     pickle.dump(pca, pca_save_path)


    def pca_transform(self, dat, dim_name):
        name_map = {
            'diease':'dieaseSmi2',
            'gene': 'dieaseSmi2',
            'met': 'dieaseSmi2',
        }
        basename = osp.splitext(dim_name)[0]
        if basename in name_map.keys():
            basename = name_map[basename]
        pca = self.pca_map[basename]
        return pca.fit_transform(dat)

pca_trans = PCATrans()