import torch
from torch import Tensor
import torch.nn.functional as F
from torch_geometric.data import HeteroData
from torch_geometric.nn import SAGEConv, GATConv, GATv2Conv, to_hetero, HeteroConv, FastRGCNConv

import torch.nn as nn
from dataset import data, device

class HeteroRGCN(torch.nn.Module):
    def __init__(self, hidden_channels, out_channels):
        super().__init__()
        self.conv1 = HeteroConv({
            key: FastRGCNConv(hidden_channels, hidden_channels, num_relations=len(data.edge_index_dict.keys()))
            for key in data.edge_index_dict.keys()
        }, aggr='sum')

        self.conv2 = HeteroConv({
            key: FastRGCNConv(hidden_channels, hidden_channels, num_relations=len(data.edge_index_dict.keys()))
            for key in data.edge_index_dict.keys()
        }, aggr='sum')

    def forward(self, x_dict, edge_index_dict):
        edge_type = {
            key: torch.ones(edge_index_dict[key].shape[1],
                            dtype=torch.long,
                            device=device) * idx
            for idx, key in enumerate(list(edge_index_dict.keys()))
        }
        # for k, v in edge_type.items():
        #     print('edge_type', k, v.shape)
        #     print('edge_index', k, edge_index_dict[k].shape)

        x_dict = self.conv1(x_dict, edge_index_dict, edge_type)
        x_dict = {
            key: F.relu(x) for key, x in x_dict.items()
        }

        x_dict = self.conv2(x_dict, edge_index_dict, edge_type)
        return x_dict


# 网络模型
# 图注意力
class GNN(torch.nn.Module):
    def __init__(self, hidden_channels):
        super().__init__()
        self.conv1 = GATv2Conv(hidden_channels, hidden_channels, head=8, add_self_loops=False)
        self.conv2 = GATv2Conv(hidden_channels, hidden_channels, head=8, add_self_loops=False)

    def forward(self, x: Tensor, edge_index: Tensor) -> Tensor:
        x = F.relu(self.conv1(x, edge_index))
        x = F.relu(self.conv2(x, edge_index)) + x
        # x = self.conv2(x, edge_index)
        return x

class SELayer(nn.Module):
    def __init__(self, channel, reduction=4):
        super(SELayer, self).__init__()
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // reduction, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(channel // reduction, channel, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        y = self.fc(x)
        return x * y.expand_as(x)

class Classifier(torch.nn.Module):
    def __init__(self, hidden_channels):
        super().__init__()
        self.att = torch.nn.MultiheadAttention(hidden_channels, 8, batch_first=True)
        self.fc1 = torch.nn.Linear(hidden_channels * 2, 1024)
        self.SE = SELayer(1024)
        self.fc2 = torch.nn.Linear(1024, 1)

    def forward(self, x_diease: Tensor, x_met: Tensor, edge_label_index: Tensor, x_diease_skip: Tensor,
                x_met_skip: Tensor) -> Tensor:
        # 读取4组特征，带skip的是不经过GNN处理的。
        edge_feat_diease = x_diease[edge_label_index[0]]
        edge_feat_met = x_met[edge_label_index[1]]
        edge_feat_diease_skip = x_diease_skip[edge_label_index[0]]
        edge_feat_met_skip = x_met_skip[edge_label_index[1]]
        # 拼接到一起
        feat_cat = torch.cat((edge_feat_diease, edge_feat_met, edge_feat_diease_skip, edge_feat_met_skip), dim=1)
        # self attention
        feat_cat_att, _ = self.att(feat_cat, feat_cat, feat_cat)
        # 将处理前后的特征拼接到一起
        feat_cat = torch.cat((feat_cat, feat_cat_att), dim=1)
        # 全连接
        feat_cat = F.relu(self.fc1(feat_cat)) + feat_cat
        feat_cat = self.SE(feat_cat)
        feat_cat = self.fc2(feat_cat)
        return feat_cat.squeeze()


class Model(torch.nn.Module):
    def __init__(self, hidden_channels):
        super().__init__()
        # 输入层
        self.gene_lin = torch.nn.Linear(data["gene"].x.shape[1], hidden_channels)
        self.diease_lin = torch.nn.Linear(data["diease"].x.shape[1], hidden_channels)
        self.met_lin = torch.nn.Linear(data["met"].x.shape[1], hidden_channels)
        # 实例化GNN
        self.gnn = HeteroRGCN(hidden_channels, hidden_channels)  # GNN(hidden_channels)
        # self.gnn = GNN(hidden_channels)
        # # GNN异质图
        # self.gnn = to_hetero(self.gnn, metadata=data.metadata())
        # 分类器
        self.classifier = Classifier(hidden_channels * 2 * 2)

    def forward(self, data: HeteroData) -> Tensor:
        x_dict = {
            "met": self.met_lin(data["met"].x),
            "diease": self.diease_lin(data["diease"].x),
            "gene": self.gene_lin(data["gene"].x),
        }

        # `x_dict` 所有节点的特征矩阵
        # `edge_index_dict` 所有边的index

        # x_dict["met"].shape
        x_dict_new = self.gnn(x_dict, data.edge_index_dict)
        pred = self.classifier(
            x_dict_new["diease"],
            x_dict_new["met"],
            data["diease", "association1", "met"].edge_label_index,
            x_dict["diease"],
            x_dict["met"],
        )
        return pred
