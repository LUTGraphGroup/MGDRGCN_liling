# import matplotlib.pyplot as plt
# import numpy as np
#
# roc = np.load(r'F:\疾病预测\shiyan\b\roc\roc1.npy')
# # 创建图像对象并设置 DPI
# # plt.figure(figsize=(5, 5),dpi=300)
# # 设置全局 DPI
# plt.rcParams['figure.dpi'] = 300
#
# # 创建图像对象
# plt.figure()
# # 绘制图像
# plt.plot([0, 1], [0, 1])
# plt.plot(np.linspace(0, 1, 101), roc, color='purple',label=f'RDAMAN: 0.8747')
# # 保存图像
# plt.savefig('high_resolution_plot.png')

import numpy as np
import pandas as pd
# import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc

mean_fpr0 = np.loadtxt('E:\python\jiangwei\mean_fpr9548.txt', delimiter=',')
mean_tpr0 = np.loadtxt('E:\python\jiangwei\mean_tpr9548.txt', delimiter=',')
mean_fpr1 = np.loadtxt('E:\python\\amhdma\AMHDMA_mean_fpr.csv', delimiter=',')
mean_tpr1 = np.loadtxt('E:\python\\amhdma\AMHDMA_mean_tpr.csv', delimiter=',')
mean_auc0 = auc(mean_fpr0, mean_tpr0)
mean_auc1 = auc(mean_fpr1, mean_tpr1)
def Draw_roc(file1, file2, file3, file4, file5, file6):
    data1 = pd.read_excel(file1)
    data1 = pd.DataFrame(data1)
    data2 = pd.read_excel(file2)
    data2 = pd.DataFrame(data2)
    data3 = pd.read_excel(file3)
    data3 = pd.DataFrame(data3)
    data4 = pd.read_excel(file4)
    data4 = pd.DataFrame(data4)
    data5 = pd.read_excel(file5)
    data5 = pd.DataFrame(data5)
    data6 = pd.read_excel(file6)
    data6 = pd.DataFrame(data6)

    # fpr_SMALF, tpr_SMALF, thresholds = roc_curve(list(data1['lable']),
    #                                                list(data1['pre']))
    # roc_auc_SMALF = auc(fpr_SMALF,tpr_SMALF)

    # fpr_VAEMDA, tpr_VAEMDA, thresholds = roc_curve(list(data2['lable']),
    #                                                list(data2['pre']))
    # roc_auc_VAEMDA = auc(fpr_VAEMDA, tpr_VAEMDA)

    fpr_GAEMDA, tpr_GAEMDA, thresholds = roc_curve(list(data3['lable']),
                                                   list(data3['pre']))
    roc_auc_GAEMDA = auc(fpr_GAEMDA, tpr_GAEMDA)

    fpr_NIMGSA, tpr_NIMGSA, thresholds = roc_curve(list(data4['lable']),
                                                   list(data4['pre']))
    roc_auc_NIMGSA = auc(fpr_NIMGSA, tpr_NIMGSA)

    fpr_VGAMF, tpr_VGAMF, thresholds = roc_curve(list(data5['lable']),
                                                   list(data5['pre']))
    roc_auc_VGAMF = auc(fpr_VGAMF, tpr_VGAMF)

    fpr_MINIMDA, tpr_MINIMDA, thresholds = roc_curve(list(data6['lable']),
                                                   list(data6['pre']))
    roc_auc_MINIMDA = auc(fpr_MINIMDA, tpr_MINIMDA)

    font = {'family': 'Times New Roman',
            'size': 12,
            }
    # sns.set(font_scale=1.2)
    plt.rc('font', family='Times New Roman')

    plt.plot(mean_fpr1, mean_tpr1, 'purple', lw=1, label='AMHDMA AUC = %0.4f' % mean_auc1)
    # plt.plot(fpr_VAEMDA, tpr_VAEMDA, 'blue', lw=1, label='VAEMDA AUC = %0.4f' % roc_auc_VAEMDA)
    plt.plot(fpr_GAEMDA, tpr_GAEMDA, 'green', lw=1, label='GAEMDA AUC = %0.4f' % roc_auc_GAEMDA)
    plt.plot(fpr_NIMGSA, tpr_NIMGSA, 'blue', lw=1, label='NIMGSA AUC = %0.4f' % roc_auc_NIMGSA)
    plt.plot(fpr_VGAMF, tpr_VGAMF, 'red', lw=1, label='VGAMF AUC = %0.4f' % roc_auc_VGAMF)
    plt.plot(fpr_MINIMDA, tpr_MINIMDA, 'pink', lw=1, label='MINIMDA AUC = %0.4f' % roc_auc_MINIMDA)
    plt.plot(mean_fpr0, mean_tpr0, color='black', lw=1, label='DAEDNN AUC = %0.4f' % mean_auc0)
    plt.legend(loc='lower right', fontsize=12)
    plt.plot([0, 1], [0, 1], 'r--')
    plt.xlabel('Flase Positive Rate', fontsize=14)
    plt.ylabel('True Positive Rate', fontsize=14)
    plt.title('ROC curve')
    plt.savefig('ROC.pdf', dpi=300)
    plt.show()


if __name__ == '__main__':
    Draw_roc('E:\python\other experience\SMALF.xlsx',
             'E:\python\other experience\VAEMDA.xlsx',
             'E:\python\other experience\GAEMDA.xlsx',
             'E:\python\other experience\\NIMGSA.xlsx',
             'E:\python\other experience\VGAMF.xlsx',
             'E:\python\other experience\MINIMDA.xlsx')